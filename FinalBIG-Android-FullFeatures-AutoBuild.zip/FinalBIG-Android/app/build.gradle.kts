plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nik.finalbig"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.nik.finalbig"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.0-alpha"
    }
}
