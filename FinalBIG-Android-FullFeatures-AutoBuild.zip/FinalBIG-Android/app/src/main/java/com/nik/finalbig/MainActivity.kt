package com.nik.finalbig

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val entries = mutableListOf<EditableEntry>()
    private val visible = mutableListOf<Int>()
    private var archiveName = "archive.big"
    private var selected = -1
    private var dirty = false
    private var pendingOutput: ByteArray? = null
    private var pendingNames: List<String>? = null

    companion object { const val OPEN=10; const val SAVE=11; const val ADD=12; const val REPLACE=13; const val SAVE_AS=14; const val EXTRACT_TREE=15 }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }
    private fun buildUi() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,12,14,8); setBackgroundColor(0xFFF4F6F8.toInt()) }
        root.addView(TextView(this).apply { text="FinalBIG Android"; textSize=25f; setTextColor(0xFF102A43.toInt()) })
        root.addView(TextView(this).apply { text="Editor arsip BIG • Alpha 1.0 • buat salinan cadangan"; textSize=12f; setTextColor(0xFF52606D.toInt()) })
        val row1=LinearLayout(this)
        row1.addView(btn("Buka BIG") { openArchive() }, wp()); row1.addView(btn("Simpan BIG") { saveArchive() }, wp()); row1.addView(btn("Simpan sebagai") { saveAs() }, wp()); root.addView(row1)
        val row2=LinearLayout(this)
        row2.addView(btn("Tambah file") { addFiles() }, wp()); row2.addView(btn("Ganti file") { replaceSelected() }, wp()); row2.addView(btn("Hapus file") { deleteSelected() }, wp()); root.addView(row2)
        val row3=LinearLayout(this)
        row3.addView(btn("Ekstrak pilihan") { extractSelected() }, wp()); row3.addView(btn("Ekstrak semua") { extractAll() }, wp()); root.addView(row3)
        search=EditText(this).apply { hint="Cari nama file…"; singleLine=true }
        root.addView(search)
        status=TextView(this).apply { text="Buka arsip .BIG untuk mulai."; textSize=13f; setTextColor(0xFF334E68.toInt()); setPadding(0,8,0,8) }; root.addView(status)
        list=ListView(this); adapter=ArrayAdapter(this, android.R.layout.simple_list_item_activated_1, mutableListOf<String>()); list.adapter=adapter
        list.setOnItemClickListener { _,_,position,_ -> selected=visible[position]; val e=entries[selected]; status.text="${e.name}\n${e.data.size} byte • ${selected+1}/${entries.size}"; list.setItemChecked(position,true) }
        search.addTextChangedListener(object: android.text.TextWatcher { override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}; override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){ refreshList() }; override fun afterTextChanged(s:android.text.Editable?){} })
        root.addView(list,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f)); setContentView(root)
    }
    private fun wp()=LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f).apply{setMargins(2,5,2,5)}
    private fun btn(t:String, f:()->Unit)=Button(this).apply{text=t; textSize=11f; setOnClickListener{f()}}
    private fun openArchive(){ val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*"}; startActivityForResult(i,OPEN) }
    private fun addFiles(){ val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true)}; startActivityForResult(i,ADD) }
    private fun replaceSelected(){ if(!validSelection())return; val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*"};startActivityForResult(i,REPLACE) }
    private fun validSelection():Boolean { if(selected !in entries.indices){ status.text="Pilih file pada daftar dahulu."; return false }; return true }
    private fun deleteSelected(){ if(!validSelection())return; AlertDialog.Builder(this).setTitle("Hapus file?").setMessage(entries[selected].name).setNegativeButton("Batal",null).setPositiveButton("Hapus"){_,_->entries.removeAt(selected);selected=-1;dirty=true;refreshList();status.text="File dihapus dari daftar. Tekan Simpan BIG untuk menyimpan perubahan."}.show() }
    private fun saveArchive(){ if(entries.isEmpty()){status.text="Arsip kosong. Tambahkan file dahulu.";return}; try{pendingOutput=BigFormat.write(entries.map{it.name to it.data}); val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/octet-stream";putExtra(Intent.EXTRA_TITLE,archiveName.ifBlank{"archive.big"})};startActivityForResult(i,SAVE)}catch(e:Exception){status.text="Gagal membuat arsip: ${e.message}"} }
    private fun saveAs(){ val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/octet-stream";putExtra(Intent.EXTRA_TITLE,"FinalBIG-edited.big")}; try{pendingOutput=BigFormat.write(entries.map{it.name to it.data});startActivityForResult(i,SAVE_AS)}catch(e:Exception){status.text="Gagal: ${e.message}"} }
    private fun extractSelected(){ if(!validSelection())return; val e=entries[selected]; val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/octet-stream";putExtra(Intent.EXTRA_TITLE,e.name.substringAfterLast('/'))};pendingOutput=e.data;startActivityForResult(i,SAVE_AS) }
    private fun extractAll(){ if(entries.isEmpty()){status.text="Belum ada arsip terbuka.";return}; startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE),EXTRACT_TREE) }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data?.data==null)return;val uri=data.data!!;try{when(requestCode){OPEN->{val bytes=contentResolver.openInputStream(uri)!!.use{it.readBytes()};val parsed=BigFormat.read(bytes);entries.clear();parsed.forEach{entries.add(EditableEntry(it.name,bytes.copyOfRange(it.offset,it.offset+it.size)))};archiveName=uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')?:"archive.big";selected=-1;dirty=false;refreshList();status.text="$archiveName • ${entries.size} file • ${bytes.size} byte"}
            SAVE,SAVE_AS->{contentResolver.openOutputStream(uri)!!.use{it.write(pendingOutput?:byteArrayOf())};status.text="Berhasil menyimpan file.";pendingOutput=null;if(requestCode==SAVE||requestCode==SAVE_AS)dirty=false}
            ADD->{val uris=mutableListOf<Uri>();if(data.clipData!=null){for(i in 0 until data.clipData!!.itemCount)uris.add(data.clipData!!.getItemAt(i).uri)}else uris.add(uri);uris.forEach{u->val name=displayName(u);val bytes=contentResolver.openInputStream(u)!!.use{it.readBytes()};entries.add(EditableEntry(uniqueName(name),bytes))};dirty=true;refreshList();status.text="Ditambahkan ${uris.size} file. Tekan Simpan BIG untuk menyimpan perubahan."}
            REPLACE->{val old=entries[selected];val bytes=contentResolver.openInputStream(uri)!!.use{it.readBytes()};entries[selected]=EditableEntry(old.name,bytes);dirty=true;refreshList();status.text="${old.name} diganti. Tekan Simpan BIG untuk menyimpan."}
            EXTRACT_TREE->{val tree=uri;contentResolver.takePersistableUriPermission(tree,data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION));val rootId=DocumentsContract.getTreeDocumentId(tree);entries.forEach{e->val path=e.name.replace('\\','/').split('/').filter{it.isNotBlank()&&it!="."&&it!=".."};if(path.isNotEmpty()){var parent=rootId;for(part in path.dropLast(1)){val children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parent);var found:String?=null;contentResolver.query(children,arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE),null,null,null)?.use{c->while(c.moveToNext()){if(c.getString(1)==part&&c.getString(2)==DocumentsContract.Document.MIME_TYPE_DIR){found=c.getString(0);break}}};parent=found?:DocumentsContract.createDocument(contentResolver,DocumentsContract.buildDocumentUriUsingTree(tree,parent),DocumentsContract.Document.MIME_TYPE_DIR,part)!!.let{DocumentsContract.getDocumentId(it)}};val doc=DocumentsContract.createDocument(contentResolver,DocumentsContract.buildDocumentUriUsingTree(tree,parent),"application/octet-stream",path.last());if(doc!=null)contentResolver.openOutputStream(doc)?.use{it.write(e.data)}}};status.text="Ekstraksi selesai: ${entries.size} entri diproses."}
        }}catch(e:Exception){status.text="Gagal: ${e.message?:e.javaClass.simpleName}"}}
    private fun displayName(uri:Uri):String { var name="file.bin";contentResolver.query(uri,arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())name=it.getString(0)};return name.replace('\\','/').substringAfterLast('/').ifBlank{"file.bin"} }
    private fun uniqueName(name:String):String { var n=name;var i=2;val names=entries.map{it.name}.toSet();while(n in names){val base=name.substringBeforeLast('.',name);val ext=name.substringAfterLast('.',"");n=if(ext.isEmpty())"$base ($i)" else "$base ($i).$ext";i++};return n }
    private fun refreshList(){val q=search.text?.toString()?.trim()?.lowercase(Locale.ROOT).orEmpty();visible.clear();visible.addAll(entries.indices.filter{entries[it].name.lowercase(Locale.ROOT).contains(q)});adapter.clear();visible.forEach{idx->val e=entries[idx];adapter.add("${e.name}\n${e.data.size} byte")};adapter.notifyDataSetChanged();if(selected !in entries.indices)selected=-1}
}
data class EditableEntry(val name:String,val data:ByteArray)
data class BigEntry(val name:String,val offset:Int,val size:Int)
object BigFormat {
 fun read(bytes:ByteArray):List<BigEntry>{require(bytes.size>=12){"File terlalu kecil"};val magic=String(bytes,0,4,Charsets.US_ASCII);require(magic=="BIGF"||magic=="BIG4"||magic=="BIG3"){"Header tidak dikenali: $magic"};fun u32(p:Int):Long{require(p>=0&&p+4<=bytes.size){"Header rusak"};return ((bytes[p].toLong() and 255) shl 24) or ((bytes[p+1].toLong() and 255) shl 16) or ((bytes[p+2].toLong() and 255) shl 8) or (bytes[p+3].toLong() and 255)};val total=u32(4);require(total<=bytes.size&&total>=12){"Ukuran arsip tidak valid"};val count=u32(8).toInt();require(count in 0..200000){"Jumlah file tidak valid"};var p=12;val out=mutableListOf<BigEntry>();repeat(count){val off=u32(p);val size=u32(p+4);p+=8;val start=p;while(p<bytes.size&&bytes[p].toInt()!=0)p++;require(p<bytes.size){"Nama file terpotong"};val name=String(bytes,start,p-start,Charsets.UTF_8);p++;require(name.isNotBlank()&&off<=bytes.size&&size<=bytes.size&&off+size<=bytes.size&&off>=p){"Rentang data tidak valid: $name"};out.add(BigEntry(name,off.toInt(),size.toInt()))};return out}
 fun write(files:List<Pair<String,ByteArray>>):ByteArray{val names=files.map{it.first.replace('\\','/').trimStart('/').toByteArray(Charsets.UTF_8)};require(names.all{it.isNotEmpty()&&!it.contains(0.toByte())}){"Nama file tidak valid"};val hs=12L+files.indices.sumOf{8L+names[it].size+1};val total=hs+files.sumOf{it.second.size.toLong()};require(total<=Int.MAX_VALUE&&total<=0xffffffffL){"Arsip terlalu besar untuk memori Android"};val out=ByteArrayOutputStream(total.toInt());fun put(v:Long){out.write(byteArrayOf((v shr 24).toByte(),(v shr 16).toByte(),(v shr 8).toByte(),v.toByte()))};out.write("BIGF".toByteArray(Charsets.US_ASCII));put(total);put(files.size.toLong());var off=hs;files.forEachIndexed{i,f->put(off);put(f.second.size.toLong());out.write(names[i]);out.write(0);off+=f.second.size};files.forEach{out.write(it.second)};return out.toByteArray()}
}
