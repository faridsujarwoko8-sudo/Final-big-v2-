# FinalBIG Android — Advanced Alpha 1.0

Fitur yang ditambahkan: buka BIGF/BIG4/BIG3 yang didukung parser, daftar dan pencarian file, ekstrak satu file, ekstrak semua dengan mempertahankan subfolder, tambah file, ganti isi entri, hapus entri, dan tulis ulang arsip BIGF.

## Build APK Windows
1. Ekstrak ZIP.
2. Pasang JDK 17, Android SDK Platform 35 dan Gradle 8.9, atau buka proyek melalui Android Studio.
3. Dari folder `FinalBIG-Android`, jalankan `gradle assembleDebug` (atau pilih Build > Build APK(s) di Android Studio).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Build otomatis GitHub
Upload isi folder `FinalBIG-Android` ke repository GitHub, termasuk `.github/workflows/android-apk.yml`. Buka Actions dan jalankan workflow. Unduh artifact `FinalBIG-Android-debug-apk`.

## Batasan penting
Ini bukan konversi penuh executable FinalBIG v2.34 dan belum setara semua fiturnya. Parser dan writer menangani struktur BIGF-family dasar; varian game/mod tertentu mungkin memiliki format/encoding berbeda. Penulisan ulang menghasilkan BIGF, bukan mempertahankan magic/header asli. Belum ada editor hex, preview W3D/CAH, kompresi, metadata, atau jaminan kompatibilitas setiap mod. Selalu buat cadangan dan uji pada salinan. Arsip besar bisa menghabiskan RAM karena data dimuat ke memori.
